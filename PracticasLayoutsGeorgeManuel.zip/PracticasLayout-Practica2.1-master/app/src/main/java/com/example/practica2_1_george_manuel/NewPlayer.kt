package com.example.practica2_1_george_manuel

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class NewPlayer : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.newplayer)//xml de newplayer
    }
}
